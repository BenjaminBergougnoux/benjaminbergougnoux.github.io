
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <time.h>

#include "fifo.h"

#define NEXT(p)     (((p) + 1) % MAX_FIFO)


/**********************************************************
** CrÃ©er une file
***********************************************************/

FIFO* new_fifo(char *name) {
    FIFO *fifo = malloc(sizeof(FIFO));
    assert(fifo != NULL);
    fifo->in = fifo->out = fifo->size = 0;
    fifo->name = name;
    fifo->next = -1;
    return fifo;
}


/**********************************************************
** Obtenir la taille d'une file
***********************************************************/

int fifo_size(FIFO *f) {
    return f->size;
}


/**********************************************************
** RÃ©cupÃ©rer la queue de file (NULL si vide)
***********************************************************/

void* fifo_get(FIFO *f) {
    if (f->size == 0) return NULL;
    void *pid = f->pointers[ f->out ];
    f->out = NEXT(f->out);
    f->size--;
    return pid;
}


/**********************************************************
** placer une valeur en tete de file
***********************************************************/

void fifo_put(FIFO *f, void *pid) {
    if (f->size == MAX_FIFO) {
        fprintf(stderr, "La pile %s est pleine : ", f->name);
        exit(EXIT_FAILURE);
    }
    f->pointers[ f->in ] = pid;
    f->in = NEXT(f->in);
    f->size++;
}


/**********************************************************
** supprimer une valeur
***********************************************************/

void fifo_remove(FIFO *f, void *pid) {
    for(int p = f->out, n = f->size; n > 0; p = NEXT(p), n--) {
        if (f->pointers[ p ] == pid) {
            n--;
            if (p == f->out) {
                fifo_get(f);
                return;
            }
            while (n-- > 0) {
                int next = NEXT(p);
                f->pointers[ p ] = f->pointers[ next ];
                p = next;
            }
            f->in = p;
            f->size --;
            return;
        }
    }
}


/**********************************************************
** itÃ©rer sur une file (NULL si terminÃ©e)
***********************************************************/

void *fifo_next(FIFO *f) {
    if (f->next < 0) {
        // copier les Ã©lements
        int n = 0;
        for(int p = f->out; n < f->size; p = NEXT(p)) {
            f->copy_for_iteration[n++] = f->pointers[p];
        }
        f->copy_for_iteration[n] = NULL;
        f->next = 0;
    }
    if (f->copy_for_iteration[f->next] == NULL) {
        f->next = -1;
        return NULL;
    }
    return f->copy_for_iteration[ f->next++ ];
}



