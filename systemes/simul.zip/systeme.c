
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <time.h>

#include "cpu.h"
#include "asm.h"
#include "fifo.h"
#include "systeme.h"


/**********************************************************
** Structures de données de l'ordonnanceur (représentation
** d'un ensemble de threads).
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

typedef enum {
    EMPTY =   0,            /* thread non-prêt          */
    READY =   1,            /* thread prêt              */
} STATE;                    /* État d'un thread         */

typedef struct {
    int    pid;             /* PID du thread            */
    PSW    cpu;             /* mot d'état du processeur */
    STATE  state;           /* état du thread           */
} THREAD;                   /* Un thread                */


/**********************************************************
** Ajouter une entrée dans le tableau des threads.
**
** 1) allouer dynamiquement une structure THREAD
** 2) affecter le PSW et l'état READY.
** 2) affecter le champ pid (avec maxpid).
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

THREAD *new_thread(const PSW cpu) {
    static int maxpid = 0;
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Changer l'état d'un thread
**   - L'enlever de sa file d'origine
**   - Changer son état
**   - Le ranger dans la bonne file
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void set_thread_state(THREAD *thread, int state) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Tuer un thread (le suprimer de la file et libérer
** la zone mémoire).
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void kill_thread(THREAD *thread) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Tuer les anciens threads GETCHAR.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void kill_old_getchar_threads() {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Parcourir les endormis et les réveiller
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void wakeup_sleep_threads() {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Ordonnancer l'exécution des threads.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

PSW scheduler(PSW cpu) {
    printf("Fonction scheduler() à terminer.\n");
    return cpu;
}


/**********************************************************
** Démarrage du système (création d'un code)
***********************************************************/

PSW system_init(void) {
    printf("Booting\n");
    
    // assemblage en mémoire de prog1.asm
    PSW prog1 = { .PC = assemble("prog1.asm") };
    return prog1;
}


/**********************************************************
** Traitement des appels au système
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

enum {
    SYSC_EXIT       = 100,   // terminer le thread courant
    SYSC_PUTI       = 200,   // afficher le contenu de AC
};


PSW sysc_exit(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


PSW sysc_puti(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


PSW sysc_putc(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


PSW sysc_new_thread(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


PSW sysc_sleep(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Appel système GETCHAR
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/


PSW sysc_getchar(PSW cpu) {
    printf("Fonction %s à terminer.\n", __FUNCTION__);
    exit(EXIT_FAILURE);
}


/**********************************************************
** Traitement des interruptions clavier
**
** 1) Chercher un thread dans l'état GETCHAR, lui
**    affecter le caractère et le réveiller.
** 2) Sinon, placer le caractère dans le tampon.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

void keyboard_event(WORD theChar) {
    // fonction à compléter
}


/**********************************************************
** Traitement des appels au système.
**
** SUIVEZ L'ORDRE DES QUESTIONS DU SUJET DE TP.
***********************************************************/

static PSW system_call(PSW cpu, int number) {
    switch (number) {
        case SYSC_EXIT:
            cpu = sysc_exit(cpu);
            break;
        case SYSC_PUTI:
            cpu = sysc_puti(cpu);
            break;
        default:
            printf("Appel système inconnu %d\n", number);
            break;
    }
    return cpu;
}


/**********************************************************
** Traitement des interruptions par le système (mode système)
***********************************************************/

PSW process_interrupt(PSW cpu) {
    //dump_cpu(cpu); sleep(1);
    switch (cpu.IN) {
        case INT_SEGV:
            break;
        case INT_INST:
            break;
        case INT_TRACE:
            break;
        case INT_KEYBOARD:
            break;
        default:
            cpu = system_call(cpu, cpu.IN);
            break;
    }
    return cpu;
}
