
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "cpu.h"
#include "mmu.h"

/* ============================================================================
 _   _ _____   ____   _    ____    __  __  ___  ____ ___ _____ ___ _____ ____
| \ | | ____| |  _ \ / \  / ___|  |  \/  |/ _ \|  _ \_ _|  ___|_ _| ____|  _ \
|  \| |  _|   | |_) / _ \ \___ \  | |\/| | | | | | | | || |_   | ||  _| | |_) |
| |\  | |___  |  __/ ___ \ ___) | | |  | | |_| | |_| | ||  _|  | || |___|  _ <
|_| \_|_____| |_| /_/   \_\____/  |_|  |_|\___/|____/___|_|   |___|_____|_| \_\

============================================================================ */

/**********************************************************
** définition de la mémoire pysique simulée
***********************************************************/
#define QUANTUM 5

static int nb_cycle =0;       /* nb de cycles effectués        */

/**********************************************************
** instruction d'addition
**
** ADD arg
**   | AC := (AC + mem[arg])
**   | PC := (PC + 1)
***********************************************************/

static PSW cpu_ADD(PSW m)
{
    WORD value = read_logical_mem(m.RI.arg, &m);
    // erreur de lecture en mémoire logique
    if (m.IN)
        return (m);
    m.AC += value;
    m.PC += 1;
    return m;
}

/**********************************************************
** instruction de soustraction
**
** SUB arg
**   | AC := (AC - mem[arg])
**   | PC := (PC + 1)
***********************************************************/

static PSW cpu_SUB(PSW m)
{
    WORD value = read_logical_mem(m.RI.arg, &m);
    // erreur de lecture en mémoire logique
    if (m.IN)
        return (m);
    m.AC -= value;
    m.PC += 1;
    return m;
}

/**********************************************************
** affectation de l'accumulateur
**
** SET arg
**   | AC := arg
**   | PC := (PC + 1)
***********************************************************/

static PSW cpu_SET(PSW m)
{
    m.AC = m.RI.arg;
    m.PC += 1;
    return m;
}

/**********************************************************
** ne rien faire (presque)
**
** NOP
**   | PC := (PC + 1)
***********************************************************/

static PSW cpu_NOP(PSW m)
{
    m.PC += 1;
    return m;
}

/**********************************************************
** lire la mémoire dans l'accumulateur
**
** LOAD adr
**   | if( arg >= 0 ) AC := mem[ adr ]
**   | if( arg < 0 ) AC := mem[ PTR ]
**   | PC := (PC + 1)
***********************************************************/

static PSW cpu_LOAD(PSW m)
{
    WORD arg = (m.RI.arg);
    WORD value;
    if (arg < 0)
    {
        value = read_logical_mem(m.PTR, &m);
    }
    else
    {
        value = read_logical_mem(arg, &m);
    }

    // erreur de lecture en mémoire logique
    if (m.IN)
        return (m);

    // lecture réussie
    m.AC = value;
    m.PC += 1;
    return m;
}

/**********************************************************
** sauver l'accumulateur en mémoire.
**
** STORE arg
**   | if( arg >= 0 ) mem[ adr ] := AC
**   | if( arg < 0 )  mem[ PTR ] := AC
**   | PC := (PC + 1)
***********************************************************/

static PSW cpu_STORE(PSW m)
{
    WORD arg = (m.RI.arg);
    if (arg < 0)
    {
        write_logical_mem(m.PTR, &m, m.AC);
    }
    else
    {
        write_logical_mem(arg, &m, m.AC);
    }

    // erreur d'écriture en mémoire
    if (m.IN)
        return (m);

    // écriture réussie
    m.PC += 1;
    return m;
}

/**********************************************************
** saut inconditionnel.
**
** JUMP offset
**   | PC := offset
***********************************************************/

static PSW cpu_JUMP(PSW m)
{
    m.PC = m.RI.arg;
    return m;
}

/**********************************************************
** saut si plus grand que.
**
** IFGT offset
**   | if (AC > 0) PC := offset
**   | else PC := (PC + 1)
***********************************************************/

static PSW cpu_IFGT(PSW m)
{
    if (m.AC > 0)
    {
        m.PC = m.RI.arg;
    }
    else
    {
        m.PC += 1;
    }
    return m;
}

/**********************************************************
** saut si égale.
**
** IFEQ offset
**   | if (AC == 0) PC := offset
**   | else PC := (PC + 1)
***********************************************************/

static PSW cpu_IFEQ(PSW m)
{
    if (m.AC == 0)
    {
        m.PC = m.RI.arg;
    }
    else
    {
        m.PC += 1;
    }
    return m;
}

/**********************************************************
** saut si plus petit que.
**
** IFLT offset
**   | if (AC < 0) PC := offset
**   | else PC := (PC + 1)
***********************************************************/

static PSW cpu_IFLT(PSW m)
{
    if (m.AC < 0)
    {
        m.PC = m.RI.arg;
    }
    else
    {
        m.PC += 1;
    }
    return m;
}

/**********************************************************
** appel au système (interruption SYSC)
**
** SYSC arg
**   | PC := (PC + 1)
**   | <interruption cause SYSC>
***********************************************************/

static PSW cpu_SYSC(PSW m)
{
    m.PC += 1;
    m.IN = INT_SYSC;
    return m;
}

/**********************************************************
** Échange la valeur des registres AC et PTR
**
** SWITCH
**   | PC := (PC + 1)
**   | AC := AC + PTR
**   | PTR := AC - PTR
**   | AC := AC - PTR
***********************************************************/

static PSW cpu_SWITCH(PSW m)
{
    m.PC += 1;
    m.AC = m.AC + m.PTR;
    m.PTR = m.AC - m.PTR;
    m.AC = m.AC - m.PTR;
    return m;
}

/**********************************************************
** Simulation de la CPU (mode utilisateur)
***********************************************************/

PSW simulate_cpu(PSW m)
{
    /* pas d'interruption */
    m.IN = INT_NONE;

    /* incrementation du nombre de cycle */
    nb_cycle++;

    /*** lecture et décodage de l'instruction ***/
    WORD value = read_logical_mem(m.PC, &m);
    if (m.IN)
        return (m);

    m.RI = decode_instruction(value);

    /*** exécution de l'instruction ***/
    switch (m.RI.op)
    {
    case INST_SET:
        m = cpu_SET(m);
        break;
    case INST_ADD:
        m = cpu_ADD(m);
        break;
    case INST_SUB:
        m = cpu_SUB(m);
        break;
    case INST_NOP:
        m = cpu_NOP(m);
        break;
    case INST_LOAD:
        m = cpu_LOAD(m);
        break;
    case INST_STORE:
        m = cpu_STORE(m);
        break;
    case INST_JUMP:
        m = cpu_JUMP(m);
        break;
    case INST_IFEQ:
        m = cpu_IFEQ(m);
        break;
    case INST_IFGT:
        m = cpu_IFGT(m);
        break;
    case INST_IFLT:
        m = cpu_IFLT(m);
        break;
    case INST_SYSC:
        m = cpu_SYSC(m);
        break;
    case INST_SWITCH:
        m = cpu_SWITCH(m);
        break;
    default:
        /*** interruption instruction inconnue ***/
        m.IN = INT_INST;
        return (m);
    }
    
    /*** arrêt si l'instruction a provoqué une interruption ***/
    if (m.IN)
        return m;

    /*** si fin du quantum, on provoque une interruption ***/
    if (nb_cycle % QUANTUM == 0)
    {
        m.IN = INT_QUANTUM;
        return m;
    }

    /*** interruption après chaque instruction ***/
    m.IN = INT_TRACE;
    return m;
}

/**********************************************************
** afficher les registres de la CPU
***********************************************************/

void dump_cpu(PSW m)
{
    printf("PID = %2d | ", m.PID);
    printf("PC = %3d | ", m.PC);
    printf("AC = %4d |  ", m.AC);
    printf("PTR = %4d | IN = ", m.PTR);
    print_interruption(m.IN);
    printf(" | RI = ");
    print_instruction(m.RI);
    printf("\n\n");
}
