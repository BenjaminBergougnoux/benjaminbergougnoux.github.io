#include "mmu.h"
#include "memory.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

/**********************************************************
** définitions pour la pagination
***********************************************************/

#define PAGE_SIZE (8)                  // Taille d'une page en nombre de mots mémoire (WORD)
#define NB_PAGES (MAX_MEM / PAGE_SIZE) // Nombre de pages physiques

/* Valeur utilisé en mémoire dans les tables des pages
pour dire qu'aucune page physique n'est assignée à cette page logique */
#define NOT_ASSIGNED (-2)

typedef enum
{
    USED = 0, /* page utilisée          */
    FREE = 1, /* page inutilisée         */
} STATE;      /* État d'une page         */

static STATE physical_pages[NB_PAGES]; /* Table des pages physiques                       */

/**********************************************************
** Décoder un mot en addresse logique pour récuperer
** le numéro de page et le déplacement
***********************************************************/

int get_page_number(int addr)
{
    return addr / PAGE_SIZE;
}

int get_offset(int addr)
{
    return addr % PAGE_SIZE;
}

/**********************************************************
** Créer une addresse à partir d'un numéro de page et d'un déplacement
***********************************************************/

int encode_addresse(int page_nb, int offset)
{
    return offset + (PAGE_SIZE * page_nb);
}

/**********************************************************
** Initialisation de la mémoire
***********************************************************/

void init_memory(void)
{
    for (int adr = 0; (adr < MAX_MEM); adr++)
    {
        write_mem(adr, -1);
    }

    for (int i = 0; (i < NB_PAGES); i++)
    {
        physical_pages[i] = FREE;
    }
}

/**********************************************************
** Fonction qui renvoie l'addresse physique du premier mot mémoire d'une page physique
***********************************************************/

int first_word(int page_number)
{
    return page_number * PAGE_SIZE;
}

/**********************************************************
** Fonction verifiant si  une addresse logique est valide
**
** À implémenter :
** Une addresse logique doit être positive et pas trop grande !
***********************************************************/

bool is_logical_address(int value)
{
    return 1;
}

/**********************************************************
** Fonction pour trouver une page libre dans la table des pages
**
** Histoire de ne pas allouer que des pages consécutive à chaque fois,
** on commence la recherche à partir d'un indice aléatoire avec la fonction random_page_number().
**
** Pensez à mettre à jour la table des pages physique
** Si aucune page n'est libre, on termine la simulation sur une erreur
**
** À compléter
***********************************************************/

int random_page_number(void)
{
    return rand() % NB_PAGES;
}

int allocate_page(void)
{
    // Garder les lignes suivantes pour le cas où aucune page n'est libre
    printf("ERROR: allocate_page : no free page");
    exit(EXIT_FAILURE);
}

/**********************************************************
** Fonction allouant une page à une processus pour y stocké sa table des pages
** ** À implémenter :
** L'addresse physique de la première entrée de cette table est a stocké dans le registre RB
** Chaque entrée de cette table des pages est initialisée à NOT_ASSIGNED
***********************************************************/

void init_processus_memory(PSW *cpu)
{
    if (cpu == NULL)
    {
        fprintf(stderr, "ERROR: read_logical_mem: NULL cpu\n");
        exit(EXIT_FAILURE);
    }
    return;
}

/**********************************************************
** Fonction qui assigne une page physique à la page logique page_number d'un processus
**
** À implémenter :
** 1) utiliser allocate_page() pour trouver une page physique libre,
** 2) écrire le numéro de cette page physique dans la table des pages à l'indice page_number
**
** Pas besoin de verifier si le page_number est valide
***********************************************************/

void assign_page(int page_number, PSW *cpu)
{
    return;
}

/**********************************************************
** Conversion d'une addresse logique en addresse physique
** Initialement : 0 abstraction : logique = physique
**
** À modifier pour implémenter une mémoire paginée :
** 1) récuperer le numéro de page et le déplacement de l'addresse logique avec get_page_number() et get_offset()
** 2) Si aucune page physique n'est assignée a la page logique demandée, on le fait avec assign_page
** 3) On récupère dans la table des pages du processus le numéro de la page physique assignée à la page logique demandée
** 4) On créer une addresse physique (type ADDRESSE) et l'encode en mot mémoire avec encode_addresse(), on renvoit ce mot mémoire
***********************************************************/

WORD logical_to_physical(int logical_address, PSW *cpu)
{
    return logical_address; // Code initial : 0 abstraction
}

/**********************************************************
** Fonction permettant de libérer la mémoire d'un processus
**
** À compléter :
** On parcours la table des pages du processus pour désalouer les pages physiques associées
** Pour ça, on met à jour la table des pages physiques
** Attention certaines pages logiques sont assignée à aucune page physique (NOT_ASSIGNED)
***********************************************************/

void free_processus_memory(PSW *cpu)
{
    return;
}

/**********************************************************
** Lire une case de la mémoire logique
***********************************************************/

WORD read_logical_mem(int logical_address, PSW *cpu)
{
    if (cpu == NULL)
    {
        fprintf(stderr, "ERROR: read_logical_mem: NULL cpu\n");
        exit(EXIT_FAILURE);
    }
    if (!is_logical_address(logical_address))
    {
        cpu->IN = INT_SEGV;
        return (0); // Adresse logique non-valide : on provoque une interruption INT_SEGV
    }
    return read_mem(logical_to_physical(logical_address, cpu));
}

/**********************************************************
** écrire une case de la mémoire logique
***********************************************************/

void write_logical_mem(int logical_address, PSW *cpu, WORD value)
{
    if (cpu == NULL)
    {
        fprintf(stderr, "ERROR: read_logical_mem: NULL cpu\n");
        exit(EXIT_FAILURE);
    }
    if (!is_logical_address(logical_address))
    {
        cpu->IN = INT_SEGV;
        return; // Adresse logique non-valide : on provoque une interruption INT_SEGV
    }
    write_mem(logical_to_physical(logical_address, cpu), value);
}

/**********************************************************
** Test pour les fonctions à implémenter
***********************************************************/

void test_mmu(void)
{
    assert(is_logical_address(0) == 1);
    assert(is_logical_address((PAGE_SIZE * PAGE_SIZE)  -1) == 1);
    assert(is_logical_address(PAGE_SIZE * PAGE_SIZE) == 0);
    printf("Test is_logical_address() done\n");

    for (int i = 0; i < NB_PAGES; i++)
    {
        int j = allocate_page();
        assert((j < NB_PAGES) && (j >= 0));
        assert(physical_pages[j] == USED);
    }
    init_memory();
    printf("Test allocate_page() done\n");

    PSW cpu;
    init_processus_memory(&cpu);
    assert(((cpu.RB % PAGE_SIZE) == 0));
    assert(physical_pages[cpu.RB/PAGE_SIZE] == USED);
    for (int i = 0; i < MAX_MEM; i++)
    {
        if ((cpu.RB <= i) && (i < cpu.RB + PAGE_SIZE))
            assert(read_mem(i) == NOT_ASSIGNED);
        else
            assert(read_mem(i) == -1);
    }
    printf("Test init_processus_memory() done\n");

    assign_page(0, &cpu);
    int first_physical_page = read_mem(cpu.RB);
    assert((first_physical_page < NB_PAGES) && (first_physical_page >= 0));
    assign_page(7, &cpu);

    int last_physical_page = read_mem(cpu.RB + 7);
    assert((last_physical_page < NB_PAGES) && (last_physical_page >= 0));
    printf("Test assign_page() done\n");

    int physical_addr = logical_to_physical(0, &cpu);
    assert(physical_addr == first_word(first_physical_page));

    physical_addr = logical_to_physical(5, &cpu);
    assert(physical_addr == (first_word(first_physical_page) + 5));

    physical_addr = logical_to_physical(63, &cpu);
    assert(physical_addr == (first_word(last_physical_page) + 7));
    printf("Test logical_to_physical() done\n");

    free_processus_memory(&cpu);
    assert(physical_pages[first_physical_page] == FREE);
    assert(physical_pages[last_physical_page] == FREE);
    printf("Test free_processus_memory() done\nNow mmu.c shoud work...\n\n");

    init_memory(); // Reset de la mémoire et de la table des pages
}


/**********************************************************
** Affiche la mémoire
***********************************************************/

void dump_memory(void)
{
    printf("\nAffichage de la mémoire :\n");
    printf("(Une ligne = huits mots = une page, 1er colonne = numéro de page, 2eme colonne = addresse physique du premier mot)\n");
    for (int i = 0; i < MAX_MEM / PAGE_SIZE; i++)
    {
        printf("%2d|%3d||", i, i * PAGE_SIZE);
        for (int j = 0; j < PAGE_SIZE; j++)
        {
            int k = print_instruction(decode_instruction(read_mem(i * PAGE_SIZE + j)));
            printf("%*c|",9 - k, ' ');
        }
        printf("\n");
    }
    printf("\n");
}
