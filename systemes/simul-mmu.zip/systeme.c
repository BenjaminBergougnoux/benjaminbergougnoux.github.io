
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <time.h>

#include "mmu.h"
#include "cpu.h"
#include "asm.h"
#include "systeme.h"

/**********************************************************
** Structures de données de l'ordonnanceur (représentation
** d'un ensemble de processus).
***********************************************************/

#define MAX_PROCESSUS (20) /* nb maximum de processuss    */

typedef enum
{
    EMPTY = 0, /* processus inexistant          */
    READY = 1, /* processus prêt              */
} STATE;       /* État d'un processus         */

typedef struct
{
    PSW cpu;     /* mot d'état du processeur */
    STATE state; /* état du processus           */
} PCB;           /* Un Process Control Block */

PCB process[MAX_PROCESSUS]; /* table des processuss        */

/**********************************************************
** Supprime un processus
***********************************************************/

void kill_processus(PSW cpu)
{
    process[cpu.PID].state = EMPTY;
    free_processus_memory(&cpu);
    printf("Terminaison processus %2d | IN = ", cpu.PID);
    print_interruption(cpu.IN);
    printf(" | RI = ");
    print_instruction(cpu.RI);
    printf("\n\n");
}

/**********************************************************
** Ajout une entrée dans le tableau des processuss et charge son programme en mémoire
***********************************************************/

PSW new_processus(char *file_name)
{
    int pid =0;
    for(; pid < MAX_PROCESSUS; pid++)
    {
        if(process[pid].state == EMPTY)
            break;
    }
    if (pid == MAX_PROCESSUS)
    {
        printf("Erreur, new_processus() : too many processus\n");
        exit(EXIT_FAILURE);
    }

    process[pid].state = READY;
    process[pid].cpu.PC= 0;
    process[pid].cpu.PID= pid;

    init_processus_memory(&(process[pid].cpu));

    assemble(&(process[pid].cpu), file_name);

    return process[pid].cpu;
}

/**********************************************************
** Ordonnancer l'exécution des processuss.
***********************************************************/

PSW scheduler(PSW cpu)
{
    if (cpu.PID < 0 || cpu.PID >= MAX_PROCESSUS)
    {
        printf("%s : PID invalid.",__FUNCTION__);
        exit(EXIT_FAILURE);
    }

    if (process[cpu.PID].state != EMPTY)
    {
        process[cpu.PID].cpu = cpu;
    }

    for (int i = 0; i < MAX_PROCESSUS; i++)
    {
        cpu.PID = (cpu.PID + 1) % MAX_PROCESSUS;
        if (process[cpu.PID].state == READY)
        {
            return process[cpu.PID].cpu;
        }
    }
    dump_memory();
    exit(0);
}

/**********************************************************
** Démarrage du système (création d'un code)
**
** À modifier une fois mmu.c passe les test
***********************************************************/

PSW system_init(void)
{
    printf("Booting\n");

    /** Bloc à enlever une fois que mmu.c marche **/

    /*** création du processus 0 ***/
    process[0].cpu.PID = 0;
    process[0].state = READY;

    // le code de ce processus commencera à l'adresse physique 0 de la mémoire
    process[0].cpu.RB = 0;
    process[0].cpu.PC= 0;
    assemble(&(process[0].cpu), "prog1.asm");
    PSW cpu = process[0].cpu;

    /*** création du processus 1 ***/
    process[1].cpu.PID = 1;
    process[1].state = READY;

    // le code de ce processus commencera à l'adresse physique 8 de la mémoire
    process[1].cpu.RB = 8;
    process[1].cpu.PC = 8;
    assemble(&(process[1].cpu), "malveillant.asm");

    /** Find du bloc à enlever une fois que mmu.c marche **/


    /** Les eux lignes suivantes sont à décommenter quand mmu.c marche **/
    // PSW cpu = new_processus("prog1.asm");
    // new_processus("malveillant.asm");

    dump_memory();
    return cpu;
}

/**********************************************************
** Traitement des appels au système
***********************************************************/

enum
{
    SYSC_EXIT = 100, // fin du processus courant
};

PSW sysc_exit(PSW cpu)
{
    kill_processus(cpu);
    return scheduler(cpu);
}


/**********************************************************
** Traitement des appels au système.
***********************************************************/

static PSW system_call(PSW cpu)
{
    // suivant l'argument de sysc ARG
    switch (cpu.RI.arg)
    {
    case SYSC_EXIT:
        cpu = sysc_exit(cpu);
        break;
    default:
        printf("Appel système inconnu %d\n", cpu.RI.arg);
        break;
    }
    return cpu;
}

/**********************************************************
** Traitement des interruptions par le système (mode système)
***********************************************************/

PSW process_interrupt(PSW cpu)
{
    switch (cpu.IN)
    {
    case INT_SEGV:
        kill_processus(cpu);
        cpu = scheduler(cpu);
        break;
    case INT_INST:
        kill_processus(cpu);
        cpu = scheduler(cpu);
        break;
    case INT_TRACE:
        dump_cpu(cpu);
        break;
    case INT_QUANTUM:
        dump_cpu(cpu);
        sleep(2);
        cpu = scheduler(cpu);
        break;
    case INT_SYSC:
        cpu = system_call(cpu);
        break;
    default:
        break;
    }
    return cpu;
}
