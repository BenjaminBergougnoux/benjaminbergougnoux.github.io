#include "basic.h"
#include <stdio.h>
#include <assert.h>

/**********************************************************
** Vérifie taille instruction = taille mot mémoire
***********************************************************/
void test_taille()
{
    assert(sizeof(WORD) == sizeof(INST));
}

/**********************************************************
** Coder une instruction
***********************************************************/

WORD encode_instruction(INST instr)
{
    union
    {
        WORD word;
        INST instr;
    } instr_or_word;
    instr_or_word.instr = instr;
    return (instr_or_word.word);
}

/**********************************************************
** Décoder une instruction
***********************************************************/

INST decode_instruction(WORD value)
{
    union
    {
        WORD integer;
        INST instruction;
    } inst;
    inst.integer = value;
    return inst.instruction;
}

/**********************************************************
** Afficher une interruption
***********************************************************/

void print_interruption(WORD w)
{
    switch (w)
    {
    case INT_NONE:
        printf("NONE");
        break;
    case INT_SEGV:
        printf("SEGV");
        break;
    case INT_INST:
        printf("INST");
        break;
    case INT_TRACE:
        printf("TRACE");
        break;
    case INT_SYSC:
        printf("SYSC");
        break;
    case INT_QUANTUM:
        printf("QUANT");
        break;
    default:
        printf("???");
    }
}

/**********************************************************
** Afficher une instruction
***********************************************************/

int print_instruction(INST i)
{
    int n = 0;
    switch (i.op)
    {
    case INST_ADD:
        n = printf("ADD %2d", i.arg);
        break;
    case INST_IFEQ:
        n = printf("IFEQ %2d", i.arg);
        break;
    case INST_IFGT:
        n = printf("IFGT %2d", i.arg);
        break;
    case INST_IFLT:
        n = printf("IFLT %2d", i.arg);
        break;
    case INST_JUMP:
        n = printf("JUMP %2d", i.arg);
        break;
    case INST_LOAD:
        n = printf("LOAD %2d", i.arg);
        break;
    case INST_NOP:
        n = printf("NOP");
        break;
    case INST_SET:
        n = printf("SET %2d", i.arg);
        break;
    case INST_STORE:
        n = printf("STORE %2d", i.arg);
        break;
    case INST_SUB:
        n = printf("SUB %2d", i.arg);
        break;
    case INST_SYSC:
        n = printf("SYSC %2d", i.arg);
        break;
    case INST_SWITCH:
        n = printf("SWITCH");
        break;
    default:
        n = printf("  %3d", encode_instruction(i));
        break;
    }
    return n;
}