
#ifndef __FIFO_H
#define __FIFO_H


/* ============================================================================
 _   _ _____   ____   _    ____    __  __  ___  ____ ___ _____ ___ _____ ____  
| \ | | ____| |  _ \ / \  / ___|  |  \/  |/ _ \|  _ \_ _|  ___|_ _| ____|  _ \ 
|  \| |  _|   | |_) / _ \ \___ \  | |\/| | | | | | | | || |_   | ||  _| | |_) |
| |\  | |___  |  __/ ___ \ ___) | | |  | | |_| | |_| | ||  _|  | || |___|  _ < 
|_| \_|_____| |_| /_/   \_\____/  |_|  |_|\___/|____/___|_|   |___|_____|_| \_\
                                                                                                                                   
============================================================================ */

/**********************************************************
** Un file FIFO de pointeurs et les fonctions associées
***********************************************************/

#define MAX_FIFO    (20)

typedef struct {
    char *name;
    void *pointers[MAX_FIFO];
    int  in;
    int  out;
    int  size;
    void *copy_for_iteration[MAX_FIFO + 1];
    int  next;
} FIFO;

// créer une file
FIFO* new_fifo(char *name);

// obtenir la taille de la file FIFO
int fifo_size(FIFO *f);

// récupérer la queue de file (NULL si vide)
void *fifo_get(FIFO *f);

// placer une valeur en tete de file
void fifo_put(FIFO *f, void *pid);

// supprimer une valeur
void fifo_remove(FIFO *f, void *pid);

// itérer sur une file (NULL si terminée)
void *fifo_next(FIFO *f);

#endif

