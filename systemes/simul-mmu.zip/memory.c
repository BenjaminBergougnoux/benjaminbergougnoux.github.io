#include "memory.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

/**********************************************************
** définition de la mémoire
***********************************************************/

static WORD mem[MAX_MEM]; /* mémoire                       */

/**********************************************************
** Vérification pour les addresses physiques
***********************************************************/

bool is_physical_address(WORD adr)
{
    return (0 <= adr) && (adr < MAX_MEM);
}

/**********************************************************
** Lire ou écrire une case de la mémoire physique
***********************************************************/

WORD read_mem(int physical_address)
{
    if (!is_physical_address(physical_address))
    {
        fprintf(stderr, "ERROR: read_mem: bad address %d\n", physical_address);
        exit(EXIT_FAILURE);
    }
    return mem[physical_address];
}

void write_mem(int physical_address, WORD value)
{
    if (!is_physical_address(physical_address))
    {
        fprintf(stderr, "ERROR: write_mem: bad address %d\n", physical_address);
        exit(EXIT_FAILURE);
    }
    mem[physical_address] = value;
}

